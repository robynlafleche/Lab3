package com.example.simplecalculator;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    Button btn00, btn01, btn02, btn03, btn04, btn05, btn06,
            btn07, btn08, btn09, btnAdd, btnDivide,
            btnMultiply, btnMinus, btnEQ, btnClear, btnDot;
    EditText resultEdit;

    float val1, val2;

    boolean add, sub, div, mul;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn00 = (Button) findViewById(R.id.btn00);
        btn01 = (Button) findViewById(R.id.btn01);
        btn02 = (Button) findViewById(R.id.btn02);
        btn03 = (Button) findViewById(R.id.btn03);
        btn04 = (Button) findViewById(R.id.btn04);
        btn05 = (Button) findViewById(R.id.btn05);
        btn06 = (Button) findViewById(R.id.btn06);
        btn07 = (Button) findViewById(R.id.btn07);
        btn08 = (Button) findViewById(R.id.btn08);
        btn09 = (Button) findViewById(R.id.btn09);
        btnDivide = (Button) findViewById(R.id.btnDivide);
        btnMultiply = (Button) findViewById(R.id.btnMultiply);
        btnMinus = (Button) findViewById(R.id.btnMinus);
        btnEQ = (Button) findViewById(R.id.btnEQ);
        btnAdd = (Button) findViewById(R.id.btnADD);
        btnClear = (Button) findViewById(R.id.btnClear);
        btnDot = (Button) findViewById(R.id.btnDot);
        resultEdit = (EditText) findViewById(R.id.resultEdit);

        btn00.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultEdit.setText(resultEdit.getText() + "0");
            }
        });

        btn01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultEdit.setText(resultEdit.getText() + "1");
            }
        });

        btn02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultEdit.setText(resultEdit.getText() + "2");
            }
        });

        btn03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultEdit.setText(resultEdit.getText() + "3");
            }
        });

        btn04.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultEdit.setText(resultEdit.getText() + "4");
            }
        });

        btn05.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultEdit.setText(resultEdit.getText() + "5");
            }
        });

        btn06.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultEdit.setText(resultEdit.getText() + "6");
            }
        });

        btn07.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultEdit.setText(resultEdit.getText() + "7");
            }
        });

        btn08.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultEdit.setText(resultEdit.getText() + "8");
            }
        });

        btn09.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultEdit.setText(resultEdit.getText() + "9");
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (resultEdit == null) {
                    resultEdit.setText("");
                } else {
                    val1 = Float.parseFloat(resultEdit.getText() + "");
                    add = true;
                    resultEdit.setText(null);
                }
            }
        });

        btnMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val1 = Float.parseFloat(resultEdit.getText() + "");
                add = true;
                resultEdit.setText(null);}
        });

        btnMultiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val1 = Float.parseFloat(resultEdit.getText() + "");
                add = true;
                resultEdit.setText(null);
            }
        });

        btnDivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val1 = Float.parseFloat(resultEdit.getText() + "");
                add = true;
                resultEdit.setText(null);
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultEdit.setText("");
            }
        });

        btnDot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultEdit.setText(resultEdit.getText() + ".");
            }
        });

        btnEQ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val2 = Float.parseFloat(resultEdit.getText() + "");

                if (add == true) {
                    resultEdit.setText(val1 +val2 + "");
                    add = false;
                }

                if (sub == true) {
                    resultEdit.setText(val1 -val2 + "");
                    sub = false;
                }

                if (mul == true) {
                    resultEdit.setText(val1 *val2 + "");
                    mul = false;
                }

                if (div == true) {
                    resultEdit.setText(val1 /val2 + "");
                    div = false;
                }
            }
        });

    }
}